import subprocess
import sys
import os

def validate_python_code(code: str) -> tuple[bool, str]:
    """
    Проверяет Python код, запуская его в изолированном процессе.
    Возвращает (успех, сообщение_об_ошибке).
    """
    # Очищаем код от markdown-разметки, если она есть
    clean_code = code.replace("```python", "").replace("```", "").strip()

    test_file = "temp_validation_test.py"
    with open(test_file, "w", encoding="utf-8") as f:
        f.write(clean_code)

    try:
        # Запускаем код. Если есть синтаксические ошибки, они вылезут в stderr
        result = subprocess.run([sys.executable, test_file], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            return False, result.stderr
        return True, "OK"
    except subprocess.TimeoutExpired:
        return False, "Ошибка: Время выполнения кода истекло (бесконечный цикл?)"
    except Exception as e:
        return False, str(e)
    finally:
        if os.path.exists(test_file):
            os.remove(test_file)
