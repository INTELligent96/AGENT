import os
import yaml
from llm.registry import LLMRegistry
from documents.extractors import extract_text
from documents.writers import create_simple_docx
from core.prompts import SUMMARIZE_PROMPT, STRUCTURE_PROMPT, SPELLCHECK_PROMPT, CODE_PROMPT
from core.workspace import WorkspaceManager
from tools.validator import validate_python_code

class Agent:
    def __init__(self, config_path="config.yaml"):
        with open(config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        self.tools = self.config.get("tools", {})
        self.registry = LLMRegistry(config_path)

        # Инициализируем безопасность и циклы
        safety = self.config.get("safety", {})
        self.workspace = WorkspaceManager(
            workspace_dir=safety.get("workspace_dir", "workspace"),
            read_only_originals=safety.get("read_only_originals", True)
        )
        self.max_iterations = self.config.get("agent_loop", {}).get("max_iterations", 3)

    def _read_safe(self, file_path: str) -> str:
        """Безопасно читает файл, делая копию."""
        safe_path = self.workspace.prepare_file(file_path)
        return extract_text(safe_path, self.tools)

    def summarize_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("default_model")
        return llm.generate(SUMMARIZE_PROMPT.format(text=text[:8000]))

    def check_spelling_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("default_model")
        return llm.generate(SPELLCHECK_PROMPT.format(text=text[:8000]))

    def structure_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("complex_reasoning")
        return llm.generate(STRUCTURE_PROMPT.format(text=text[:8000]))

    def generate_code_with_validation(self, task: str) -> str:
        """Пишет код и итеративно исправляет его, если есть ошибки."""
        print(f"Генерация кода (максимум {self.max_iterations} попыток)...")
        llm = self.registry.get_model_for_task("code_generation")

        current_prompt = CODE_PROMPT.format(task=task)
        code = ""

        for iteration in range(1, self.max_iterations + 1):
            print(f"--- Попытка {iteration} ---")
            code = llm.generate(current_prompt)

            print("Валидация кода...")
            is_valid, error_msg = validate_python_code(code)

            if is_valid:
                print("✅ Код прошел валидацию!")
                return code

            print(f"❌ Ошибка в коде: {error_msg}")
            # Если код не прошел, добавляем ошибку в промпт для следующей итерации
            current_prompt = (
                f"Твой предыдущий код выдал ошибку:\n{error_msg}\n\n"
                f"Вот код, который ты написал:\n{code}\n\n"
                f"Пожалуйста, исправь его и верни только чистый рабочий код. Задача: {task}"
            )

        print("⚠️ Достигнут лимит попыток. Возвращаю последний вариант.")
        return code

    def save_text_to_word(self, text: str, output_path: str):
        create_simple_docx(text, output_path)
        return output_path
