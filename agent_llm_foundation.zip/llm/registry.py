import yaml
import os
from typing import Dict, Any
from .openai_compat import OpenAICompatLLM
from .manual_bridge import ManualBridgeLLM
from .base import BaseLLM

class LLMRegistry:
    """Управляет профилями моделей и роутингом задач."""
    def __init__(self, config_path: str = "config.yaml"):
        self.instances: Dict[str, BaseLLM] = {}
        self.routing = {}
        self.load_config(config_path)

    def load_config(self, config_path: str):
        if not os.path.exists(config_path):
            print(f"Файл конфигурации {config_path} не найден!")
            return

        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        profiles = config.get("llm_profiles", {})
        for name, params in profiles.items():
            if params.get("type") == "openai_compat":
                self.instances[name] = OpenAICompatLLM(
                    base_url=params["base_url"],
                    api_key=params["api_key"],
                    model_name=params["model_name"]
                )
            elif params.get("type") == "manual_bridge":
                self.instances[name] = ManualBridgeLLM()

        self.routing = config.get("routing", {})

    def get_model_for_task(self, task_type: str) -> BaseLLM:
        """Возвращает нужную модель в зависимости от типа задачи."""
        model_key = self.routing.get(task_type, self.routing.get("default_model"))
        if model_key not in self.instances:
            raise ValueError(f"Модель '{model_key}' для задачи '{task_type}' не найдена в конфиге.")
        return self.instances[model_key]
