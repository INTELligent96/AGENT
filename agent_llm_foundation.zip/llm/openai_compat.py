import requests
from typing import Optional
from .base import BaseLLM

class OpenAICompatLLM(BaseLLM):
    """
    Универсальный клиент для любого OpenAI-совместимого API.
    Отлично работает с LM Studio, DeepSeek, Qwen, OpenRouter и т.д.
    """
    def __init__(self, base_url: str, api_key: str, model_name: str):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.model_name = model_name

    def generate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        data = {
            "model": self.model_name,
            "messages": messages,
            "temperature": kwargs.get("temperature", 0.3),
            "max_tokens": kwargs.get("max_tokens", 4096),
            "stream": False
        }

        try:
            # Таймаут увеличен до 5 минут, так как локальные модели могут думать долго
            response = requests.post(url, headers=headers, json=data, timeout=300)
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Ошибка при запросе к LLM ({self.model_name}): {str(e)}"
