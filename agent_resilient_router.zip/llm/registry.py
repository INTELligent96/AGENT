import yaml
import os
import time
from typing import Dict, Any, List
from .openai_compat import OpenAICompatLLM
from .manual_bridge import ManualBridgeLLM
from .base import BaseLLM

class LLMRegistry:
    def __init__(self, config_path: str = "config.yaml"):
        self.instances: Dict[str, BaseLLM] = {}
        self.routing: Dict[str, List[str]] = {}
        self.loop_settings = {}
        self.load_config(config_path)

    def load_config(self, config_path: str):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        self.loop_settings = config.get("agent_loop", {})

        profiles = config.get("llm_profiles", {})
        for name, params in profiles.items():
            if params.get("type") == "openai_compat":
                self.instances[name] = OpenAICompatLLM(
                    base_url=params["base_url"],
                    api_key=params["api_key"],
                    model_name=params["model_name"]
                )
            elif params.get("type") == "manual_bridge":
                self.instances[name] = ManualBridgeLLM()

        self.routing = config.get("routing", {})

    def generate_with_fallback(self, task_type: str, prompt: str, system_prompt: str = None) -> str:
        """Главный метод: перебирает модели, пока какая-нибудь не ответит."""
        model_chain = self.routing.get(task_type, [])
        if not model_chain:
            return f"[Ошибка] Для задачи '{task_type}' не задана цепочка моделей."

        max_tokens = self.loop_settings.get("max_tokens_default", 4096)
        retries = self.loop_settings.get("retry_attempts", 2)
        delay = self.loop_settings.get("retry_delay_seconds", 2)

        last_error = ""

        for model_name in model_chain:
            if model_name not in self.instances:
                continue

            model = self.instances[model_name]
            print(f"--> Попытка использовать модель: {model_name}")

            # Если это ручной мост, сразу возвращаем промпт (он не делает запросов)
            if isinstance(model, ManualBridgeLLM):
                print("--> Переход на ручной мост (все модели исчерпаны).")
                return model.generate(prompt, system_prompt)

            # Вызываем API с настройками retry
            result = model.generate(
                prompt, 
                system_prompt, 
                max_tokens=max_tokens, 
                retry_attempts=retries, 
                retry_delay=delay
            )

            # Если ответ начинается с [ERROR_, значит модель окончательно упала
            if result.startswith("[ERROR_"):
                print(f"--> Модель {model_name} окончательно упала: {result}")
                last_error = result
                continue # Переходим к следующей модели в цепочке

            # Если ответ успешный - возвращаем его!
            return result

        # Если прошли весь цикл и ничего не вернули
        return f"[КРИТИЧЕСКАЯ ОШИБКА] Все модели в цепочке упали. Последняя ошибка: {last_error}"
