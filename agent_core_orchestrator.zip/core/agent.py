import os
import yaml
from llm.registry import LLMRegistry
from documents.extractors import extract_text
from documents.writers import create_simple_docx, render_template
from core.prompts import SUMMARIZE_PROMPT, STRUCTURE_PROMPT, SPELLCHECK_PROMPT, CODE_PROMPT

class Agent:
    def __init__(self, config_path="config.yaml"):
        with open(config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        self.tools = self.config.get("tools", {})
        self.registry = LLMRegistry(config_path)

    def summarize_file(self, file_path: str) -> str:
        """Читает файл и делает резюме."""
        print(f"Чтение файла: {file_path}...")
        text = extract_text(file_path, self.tools)
        if text.startswith("[Ошибка]"):
            return text

        print("Генерация резюме (local_fast)...")
        llm = self.registry.get_model_for_task("default_model")
        prompt = SUMMARIZE_PROMPT.format(text=text[:8000]) # Ограничиваем контекст для 7B
        return llm.generate(prompt)

    def check_spelling_file(self, file_path: str) -> str:
        """Читает файл и исправляет ошибки."""
        print(f"Чтение файла: {file_path}...")
        text = extract_text(file_path, self.tools)
        if text.startswith("[Ошибка]"):
            return text

        print("Проверка орфографии (local_fast)...")
        llm = self.registry.get_model_for_task("default_model")
        prompt = SPELLCHECK_PROMPT.format(text=text[:8000])
        return llm.generate(prompt)

    def structure_file(self, file_path: str) -> str:
        """Структурирует данные из файла."""
        print(f"Чтение файла: {file_path}...")
        text = extract_text(file_path, self.tools)
        if text.startswith("[Ошибка]"):
            return text

        print("Структурирование данных (local_logic)...")
        llm = self.registry.get_model_for_task("complex_reasoning")
        prompt = STRUCTURE_PROMPT.format(text=text[:8000])
        return llm.generate(prompt)

    def generate_code(self, task: str) -> str:
        """Пишет код на Python."""
        print("Генерация кода (local_coder)...")
        llm = self.registry.get_model_for_task("code_generation")
        prompt = CODE_PROMPT.format(task=task)
        return llm.generate(prompt)

    def save_text_to_word(self, text: str, output_path: str):
        """Сохраняет текст в простой Word-документ."""
        create_simple_docx(text, output_path)
        return output_path
