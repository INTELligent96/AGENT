import os

NL = "\n"


def patch(path, old, new, label):
    if not os.path.exists(path):
        print("[SKIP] Нет " + path)
        return False
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    if old not in content:
        print("[WARN] " + label + " — фрагмент не найден в " + path)
        return False
    content = content.replace(old, new, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[OK] " + label)
    return True


# ==== 1. agent.py: метод set_task_timeout ====
SET_TIMEOUT_METHOD = NL.join([
    "    def set_task_timeout(self, seconds):",
    "        try:",
    "            self.task_timeout = int(seconds)",
    "        except (ValueError, TypeError):",
    "            return 'Ошибка: введите целое число секунд'",
    "        if self.task_timeout < 30:",
    "            self.task_timeout = 30",
    "        if 'agent_loop' not in self.config:",
    "            self.config['agent_loop'] = {}",
    "        self.config['agent_loop']['task_timeout_seconds'] = self.task_timeout",
    "        try:",
    "            with open('config.yaml', 'w', encoding='utf-8') as f:",
    "                yaml.dump(self.config, f, allow_unicode=True, sort_keys=False)",
    "        except Exception as e:",
    "            return 'Ошибка сохранения: ' + str(e)",
    "        return 'Лимит времени: ' + str(self.task_timeout) + ' сек'",
    "",
    "",
])

# ==== 2. agent.py: проверка таймаута в run_task ====
OLD_RUN = NL.join([
    "        log(\"[Роутер] Анализирую запрос...\")",
    "        routing = self.router.classify(user_text)",
    "        tools = routing.get(\"tools\", [\"ask_question\"])",
    "        log(\"[Роутер] -> \" + str(tools) + \" (\" + routing.get(\"reasoning\", \"\") + \")\")",
    "",
    "        results = []",
    "        for tool_name in tools:",
    "            log(\"\\n[Инструмент] \" + tool_name)",
])
NEW_RUN = NL.join([
    "        log(\"[Роутер] Анализирую запрос...\")",
    "        routing = self.router.classify(user_text)",
    "        tools = routing.get(\"tools\", [\"ask_question\"])",
    "        log(\"[Роутер] -> \" + str(tools) + \" (\" + routing.get(\"reasoning\", \"\") + \")\")",
    "",
    "        start_time = time.time()",
    "        results = []",
    "        for tool_name in tools:",
    "            elapsed = time.time() - start_time",
    "            if elapsed > self.task_timeout:",
    "                msg = \"Истекло время (\" + str(int(self.task_timeout)) + \" сек)\"",
    "                log(\"[Таймаут] \" + msg + \" - прерываю\")",
    "                results.append(\"=== ТАЙМАУТ ===\\n\" + msg)",
    "                break",
    "            log(\"\\n[Инструмент] \" + tool_name)",
])

# ==== 3. gui/app.py: поле для лимита ====
SANDBOX_OLD = NL.join([
    "        chat_btns = ctk.CTkFrame(self.sandbox_frame, fg_color=\"transparent\")",
    "        chat_btns.pack(fill=\"x\", padx=10, pady=(0, 8))",
    "        ctk.CTkButton(chat_btns, text=\"Копировать чат\", width=130, command=self.copy_chat).pack(side=\"left\", padx=(0, 5))",
    "        ctk.CTkButton(chat_btns, text=\"Сохранить чат в файл\", width=170, command=self.save_chat_to_file).pack(side=\"left\")",
])

SANDBOX_NEW = NL.join([
    "        chat_btns = ctk.CTkFrame(self.sandbox_frame, fg_color=\"transparent\")",
    "        chat_btns.pack(fill=\"x\", padx=10, pady=(0, 8))",
    "        ctk.CTkButton(chat_btns, text=\"Копировать чат\", width=130, command=self.copy_chat).pack(side=\"left\", padx=(0, 5))",
    "        ctk.CTkButton(chat_btns, text=\"Сохранить чат в файл\", width=170, command=self.save_chat_to_file).pack(side=\"left\")",
    "",
    "        timeout_row = ctk.CTkFrame(self.sandbox_frame, fg_color=\"transparent\")",
    "        timeout_row.pack(fill=\"x\", padx=10, pady=(0, 8))",
    "        ctk.CTkLabel(timeout_row, text=\"⏱ Лимит времени на задачу (сек):\").pack(side=\"left\")",
    "        self.timeout_entry = ctk.CTkEntry(timeout_row, width=100)",
    "        self.timeout_entry.insert(0, str(self.agent.task_timeout))",
    "        self.timeout_entry.pack(side=\"left\", padx=(10, 5))",
    "        ctk.CTkButton(timeout_row, text=\"Применить\", width=100, command=self.save_timeout).pack(side=\"left\")",
])

# ==== 4. gui/app.py: метод save_timeout ====
SAVE_TIMEOUT_METHOD = NL.join([
    "    def save_timeout(self):",
    "        try:",
    "            val = int(self.timeout_entry.get())",
    "        except ValueError:",
    "            self.log(\"[Ошибка] Введите целое число секунд\")",
    "            return",
    "        result = self.agent.set_task_timeout(val)",
    "        self.timeout_entry.delete(0, \"end\")",
    "        self.timeout_entry.insert(0, str(self.agent.task_timeout))",
    "        self.log(\"[Настройки] \" + result)",
    "",
    "",
])


def main():
    print("=== 1. core/agent.py ===")
    path = "core/agent.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    if "def set_task_timeout" not in content:
        anchor = "    def request_stop(self):"
        if anchor in content:
            content = content.replace(anchor, SET_TIMEOUT_METHOD + anchor, 1)
            print("[OK] agent: set_task_timeout добавлен")
        else:
            print("[WARN] не найден request_stop")
    else:
        print("[SKIP] set_task_timeout уже есть")

    # Патч run_task
    if OLD_RUN in content:
        content = content.replace(OLD_RUN, NEW_RUN, 1)
        print("[OK] agent: проверка таймаута в run_task")
    else:
        print("[WARN] run_task — фрагмент не найден")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print("")
    print("=== 2. gui/app.py ===")
    path = "gui/app.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    if "timeout_entry" not in content:
        if SANDBOX_OLD in content:
            content = content.replace(SANDBOX_OLD, SANDBOX_NEW, 1)
            print("[OK] gui: поле лимита времени добавлено")
        else:
            print("[WARN] не найден sandbox chat_btns")
    else:
        print("[SKIP] timeout_entry уже есть")

    if "def save_timeout" not in content:
        anchor = "    def stop_agent(self):"
        if anchor in content:
            content = content.replace(anchor, SAVE_TIMEOUT_METHOD + anchor, 1)
            print("[OK] gui: save_timeout добавлен")
        else:
            print("[WARN] не найден stop_agent")
    else:
        print("[SKIP] save_timeout уже есть")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print("")
    print("Готово! Запускай: python main.py")
    print("В правой панели появится поле '⏱ Лимит времени на задачу' с кнопкой 'Применить'.")
    print("")
    print("ВАЖНО: таймаут проверяется МЕЖДУ инструментами.")
    print("Если инструмент уже запущен (например, batch_summarize), он доработает до конца.")


if __name__ == "__main__":
    main()