import os

NL = "\n"


# ============ 1. core/self_check.py — перезапись ============
CRITIC = NL.join([
    "import json",
    "from llm.registry import LLMRegistry",
    "",
    "",
    "class Critic:",
    "    def __init__(self, registry, config):",
    "        self.registry = registry",
    "        cfg = config.get('self_check', {})",
    "        self.enabled = cfg.get('enabled', True)",
    "        self.force_always = cfg.get('force_always', False)",
    "        self.max_retries = cfg.get('max_retries', 2)",
    "        self.min_score = cfg.get('min_score', 7)",
    "        self.critic_model_key = cfg.get('critic_model', 'local_logic')",
    "        self.default_critic_key = cfg.get('default_model_for_check', 'local_fast')",
    "",
    "    def should_check(self, task_type):",
    "        if not self.enabled:",
    "            return False",
    "        if self.force_always:",
    "            return True",
    "        return task_type in ['rag', 'summarize', 'translate', 'structure']",
    "",
    "    def check_factual(self, context, answer):",
    "        prompt = (",
    "            'Ты - фактчекер. Проверь, все ли КОНКРЕТНЫЕ факты (имена, числа, даты, названия) в ответе '",
    "            'подтверждаются контекстом.\\n\\n'",
    "            'КОНТЕКСТ:\\n' + context[:6000] + '\\n\\n'",
    "            'ОТВЕТ:\\n' + answer + '\\n\\n'",
    "            'Верни ТОЛЬКО JSON без markdown:\\n'",
    "            '{\"score\": 1-10, \"unverified_claims\": [], \"verdict\": \"accept\" или \"retry\"}\\n\\n'",
    "            'Правила:\\n'",
    "            '- Если в ответе есть конкретное имя/число/факт, и оно есть в контексте — accept, score 9-10.\\n'",
    "            '- Если в ответе сказано \"не найдено\", а в контексте факт ЕСТЬ — retry, score 3-4.\\n'",
    "            '- Если в ответе есть выдуманные факты (которых нет в контексте) — retry, score 4-5.\\n'",
    "            '- Если ответ просто пересказывает контекст без искажений — accept, score 9.'",
    "        )",
    "        raw = self.registry.generate_with_fallback(self.critic_model_key, prompt)",
    "        return self._parse(raw)",
    "",
    "    def check_general(self, task, answer, task_type):",
    "        model_key = self.critic_model_key if task_type == 'rag' else self.default_critic_key",
    "        prompt = (",
    "            'Ты - критик. Оцени, отвечает ли ответ на задачу.\\n\\n'",
    "            'ЗАДАЧА: ' + task + '\\n'",
    "            'ОТВЕТ: ' + answer + '\\n\\n'",
    "            'Верни ТОЛЬКО JSON без markdown:\\n'",
    "            '{\"score\": 1-10, \"issues\": [], \"verdict\": \"accept\" или \"retry\"}\\n\\n'",
    "            'Правила (ВАЖНО - будь объективным):\\n'",
    "            '- Если ответ содержит конкретный ответ на вопрос (имя, число, факт) — accept, score 8-10.\\n'",
    "            '- Если ответ - \"не найдено\", но вопрос простой — retry, score 3-4.\\n'",
    "            '- Если ответ размытый или уклончивый — retry, score 5-6.\\n'",
    "            '- НЕ придирайся к стилю, длине или оформлению.'",
    "        )",
    "        raw = self.registry.generate_with_fallback(model_key, prompt)",
    "        return self._parse(raw)",
    "",
    "    def _parse(self, raw):",
    "        try:",
    "            clean = raw.replace('```json', '').replace('```', '').strip()",
    "            data = json.loads(clean)",
    "            data.setdefault('score', 5)",
    "            data.setdefault('verdict', 'retry')",
    "            data.setdefault('issues', [])",
    "            return data",
    "        except Exception:",
    "            return {'score': 7, 'issues': ['Критик не дал валидный JSON, считаем OK'], 'verdict': 'accept'}",
    "",
    "    def run_with_retry(self, generate_fn, task, task_type, context=None):",
    "        if not self.should_check(task_type):",
    "            return generate_fn('')",
    "        best_answer = None",
    "        best_score = 0",
    "        last_issues = []",
    "        for attempt in range(self.max_retries + 1):",
    "            if attempt == 0:",
    "                answer = generate_fn('')",
    "            else:",
    "                fb = (",
    "                    'Твой предыдущий ответ забракован.\\n'",
    "                    'Замечания: ' + str(last_issues) + '\\n'",
    "                    'Предыдущий ответ:\\n' + str(best_answer) + '\\n\\n'",
    "                    'Перепиши, устранив проблемы.'",
    "                )",
    "                answer = generate_fn(fb)",
    "            if task_type == 'rag' and context:",
    "                verdict = self.check_factual(context, answer)",
    "            else:",
    "                verdict = self.check_general(task, answer, task_type)",
    "            score = verdict.get('score', 0)",
    "            print('  [Критик] Попытка ' + str(attempt + 1) + ': score=' + str(score) + ', verdict=' + str(verdict.get('verdict')))",
    "            if score > best_score:",
    "                best_score = score",
    "                best_answer = answer",
    "            if verdict.get('verdict') == 'accept' and score >= self.min_score:",
    "                return answer",
    "            last_issues = verdict.get('issues') or verdict.get('unverified_claims') or ['не указаны']",
    "        # Мягкий финал: если score >= 6, возвращаем без ругани",
    "        if best_score >= 6:",
    "            return best_answer",
    "        print('  [Критик] Лимит. Лучший score=' + str(best_score))",
    "        return '[Критик: качество ниже нормы, score=' + str(best_score) + ', замечания: ' + str(last_issues) + ']\\n\\n' + str(best_answer)",
    "",
])


# ============ 2. core/agent.py — передаём context в критика для RAG ============
# В ask_question мы сейчас вызывем rag.ask() — а критик работает ВНУТРИ run_with_retry в _execute_tool
# Нам нужно, чтобы для RAG критик получал контекст из чанков.
# Самый простой путь: сделать метод ask_question_with_critic()

NEW_ASK_METHOD = NL.join([
    "    def ask_question_with_critic(self, question, folder_filter=None):",
    "        # Особый путь для RAG: сначала получаем чанки, потом критик проверяет по ним",
    "        search_query = self.rag._build_search_query(question, self.chat_history)",
    "        where = self.rag._get_source_filter(folder_filter)",
    "        chunks = self.rag.indexer.search(search_query, top_k=12, where=where)",
    "        if not chunks:",
    "            return 'В базе данных не найдено информации по этому вопросу.'",
    "        # Собираем контекст для критика",
    "        from pathlib import Path as _P",
    "        context_for_critic = ''",
    "        for c in chunks:",
    "            context_for_critic += c['text'] + '\\n\\n'",
    "        # Генерируем ответ через RAG",
    "        def gen(feedback):",
    "            q = question if not feedback else (question + '\\n\\n' + feedback)",
    "            return self.rag.ask(q, history=self.chat_history, last_folder=self.last_folder, folder_filter=folder_filter)",
    "        return self.critic.run_with_retry(gen, task=question, task_type='rag', context=context_for_critic)",
    "",
])


def main():
    # 1. self_check.py — перезапись
    print("=== 1. core/self_check.py ===")
    with open("core/self_check.py", "w", encoding="utf-8") as f:
        f.write(CRITIC)
    print("[OK] self_check.py перезаписан")

    # 2. config.yaml — min_score 8 → 7
    print("")
    print("=== 2. config.yaml ===")
    if os.path.exists("config.yaml"):
        with open("config.yaml", "r", encoding="utf-8") as f:
            content = f.read()
        if "min_score: 8" in content:
            content = content.replace("min_score: 8", "min_score: 7")
            print("[OK] min_score: 8 → 7")
        elif "min_score: 7" in content:
            print("[SKIP] min_score уже 7")
        else:
            print("[WARN] min_score не найден в config.yaml")
        with open("config.yaml", "w", encoding="utf-8") as f:
            f.write(content)

    # 3. agent.py — добавляем ask_question_with_critic + меняем вызов в ask_question в _execute_tool
    print("")
    print("=== 3. core/agent.py ===")
    path = "core/agent.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    # Вставляем новый метод перед "def ask_question"
    if "def ask_question_with_critic" not in content:
        anchor = "    def ask_question(self, question"
        if anchor in content:
            content = content.replace(anchor, NEW_ASK_METHOD + "\n" + anchor, 1)
            print("[OK] ask_question_with_critic добавлен")
        else:
            print("[WARN] не найден ask_question")
    else:
        print("[SKIP] ask_question_with_critic уже есть")

    # Меняем вызов ask_question (с критиком) в _execute_tool
    old_call = NL.join([
        "        if tool_name == \"ask_question\":",
        "            def gen(feedback):",
        "                base = user_text if not feedback else (user_text + \"\\n\\n\" + feedback)",
        "                return self.ask_question(base)",
        "            return self.critic.run_with_retry(gen, task=user_text, task_type=\"rag\")",
    ])
    new_call = NL.join([
        "        if tool_name == \"ask_question\":",
        "            return self.ask_question_with_critic(user_text)",
    ])
    if old_call in content:
        content = content.replace(old_call, new_call, 1)
        print("[OK] ask_question в _execute_tool → ask_question_with_critic")
    else:
        # Пробуем найти одиночный вызов без critical
        old_call2 = NL.join([
            "        if tool_name == \"ask_question\":",
            "            def gen(feedback):",
            "                base = user_text if not feedback else (user_text + \"\\n\\n\" + feedback)",
            "                return self.ask_question(base)",
            "            return self.critic.run_with_retry(gen, task=user_text, task_type=\"rag\")",
        ])
        if old_call2 in content:
            content = content.replace(old_call2, new_call, 1)
            print("[OK] ask_question в _execute_tool → ask_question_with_critic (вариант 2)")
        else:
            print("[WARN] не нашли вызов ask_question в _execute_tool")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print("")
    print("=" * 60)
    print("ГОТОВО! Запускай: python main.py")
    print("=" * 60)
    print("")
    print("Что проверить:")
    print("1. 'а кто директор?' → должен быть ответ без [ВНИМАНИЕ: критик...]")
    print("2. Критик теперь мягче: score >= 7 = accept")
    print("3. Для RAG используется factual check (проверка по контексту)")


if __name__ == "__main__":
    main()