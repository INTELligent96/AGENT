import os


NL = "\n"


# ============ 1. Правка логики skip_if ============
OLD_TEST_FUNC = NL.join([
    "def test(name, fn, skip_if=None):",
    "    global PASSED, FAILED, SKIPPED",
    "    if skip_if and not skip_if():",
    "        print(\"  [SKIP] \" + name)",
    "        SKIPPED += 1",
    "        return",
])
NEW_TEST_FUNC = NL.join([
    "def test(name, fn, skip_if=None):",
    "    global PASSED, FAILED, SKIPPED",
    "    if skip_if and skip_if():",
    "        print(\"  [SKIP] \" + name)",
    "        SKIPPED += 1",
    "        return",
])


# ============ 2. Правка теста Word-стилей ============
OLD_WORD = NL.join([
    "    def t_word_styles():",
    "        from documents.style_engine import WordStyleEngine",
    "        eng = WordStyleEngine(str(root / \"contract.docx\"))",
    "        styles = eng.get_document_styles(str(root / \"doc1.txt\"))",
    "        return isinstance(styles, list)",
])
NEW_WORD = NL.join([
    "    def t_word_styles():",
    "        from documents.style_engine import WordStyleEngine",
    "        eng = WordStyleEngine(str(root / \"contract.docx\"))",
    "        styles = eng.get_document_styles(str(root / \"contract.docx\"))",
    "        return isinstance(styles, list)",
])


def main():
    path = "test_full_v2.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    if OLD_TEST_FUNC in content:
        content = content.replace(OLD_TEST_FUNC, NEW_TEST_FUNC, 1)
        print("[OK] test: логика skip_if исправлена")
    else:
        print("[WARN] не найден блок test()")

    if OLD_WORD in content:
        content = content.replace(OLD_WORD, NEW_WORD, 1)
        print("[OK] test: Word-стили на .docx")
    else:
        print("[WARN] не найден t_word_styles")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print("")
    print("Готово! Запускай: python test_full_v2.py")


if __name__ == "__main__":
    main()