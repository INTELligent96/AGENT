import subprocess
import os
from pathlib import Path

def convert_to_modern(file_path: str, libreoffice_path: str) -> str:
    """
    Конвертирует .doc -> .docx и .xls -> .xlsx через LibreOffice.
    Возвращает путь к новому файлу.
    """
    file_path = Path(file_path)
    out_dir = file_path.parent

    # Определяем целевой формат
    if file_path.suffix.lower() == '.doc':
        target_format = 'docx'
    elif file_path.suffix.lower() == '.xls':
        target_format = 'xlsx'
    else:
        return str(file_path)

    print(f"Конвертация {file_path.name} в {target_format}...")

    # Запуск LibreOffice в headless-режиме
    try:
        subprocess.run([
            libreoffice_path,
            '--headless',
            '--convert-to', target_format,
            '--outdir', str(out_dir),
            str(file_path)
        ], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        new_file = out_dir / f"{file_path.stem}.{target_format}"
        if new_file.exists():
            return str(new_file)
        else:
            raise FileNotFoundError("Конвертация не удалась, файл не создан.")
    except Exception as e:
        print(f"Ошибка конвертации (проверь путь к LibreOffice): {e}")
        return str(file_path)
