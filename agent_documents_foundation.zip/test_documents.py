import yaml
import os
from documents.extractors import extract_text
from documents.writers import create_simple_docx, render_template

def main():
    # Загружаем конфиг для путей к Tesseract и LibreOffice
    with open("config.yaml", "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    tools = config.get("tools", {})

    print("--- Тест 1: Создание и чтение Word (.docx) ---")
    test_file = "test_output.docx"
    create_simple_docx("Привет! Это тестовый документ для проверки стилей.", test_file)
    print("Создан файл:", test_file)
    text = extract_text(test_file, tools)
    print("Прочитан текст:", text)

    print("\n--- Тест 2: Чтение Excel (.xlsx) ---")
    # Создадим тестовый Excel
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Имя", "Возраст"])
    ws.append(["Иван", 30])
    wb.save("test_excel.xlsx")
    print(extract_text("test_excel.xlsx", tools))

    print("\n--- Тест 3: Проверка OCR (Tesseract) ---")
    print(f"Путь к Tesseract: {tools.get('tesseract_path')}")
    if os.path.exists(tools.get('tesseract_path', '')):
        print("Tesseract найден. (Тест картинки пропущен для экономии времени)")
    else:
        print("[Внимание] Tesseract не найден по указанному пути. OCR не будет работать.")

if __name__ == "__main__":
    main()
