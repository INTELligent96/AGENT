import os
from core.agent import Agent

def main():
    # Создадим тестовую папку с документами
    test_dir = "test_rag_folder"
    os.makedirs(test_dir, exist_ok=True)

    # Создадим пару файлов
    with open(os.path.join(test_dir, "doc1.txt"), "w", encoding="utf-8") as f:
        f.write("Компания Рога и Копыта была основана в 1995 году в городе Москва. "
                "Основной вид деятельности - продажа рогов и копыт. "
                "Генеральный директор - Иван Иванович Петров.")

    with open(os.path.join(test_dir, "doc2.txt"), "w", encoding="utf-8") as f:
        f.write("Филиал компании Рога и Копыта находится в Санкт-Петербурге. "
                "Адрес: Невский проспект, дом 10. "
                "Контактный телефон: 8-800-555-35-35.")

    print("Инициализация агента...")
    agent = Agent("config.yaml")

    print("\n=== ТЕСТ 1: Индексация папки ===")
    agent.index_folder(test_dir)

    print("\n=== ТЕСТ 2: Вопрос по документам ===")
    questions = [
        "В каком году основана компания Рога и Копыта?",
        "Какой телефон у филиала в Санкт-Петербурге?",
        "Кто генеральный директор?"
    ]

    for q in questions:
        print(f"\n--- ВОПРОС: {q} ---")
        answer = agent.ask_question(q)
        print(f"ОТВЕТ:\n{answer}")

if __name__ == "__main__":
    main()
