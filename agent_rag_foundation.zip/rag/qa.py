from .indexer import RAGIndexer
from llm.registry import LLMRegistry

class RAGQuestionAnswerer:
    def __init__(self, config: dict, tools_config: dict, registry: LLMRegistry):
        self.indexer = RAGIndexer(config, tools_config)
        self.registry = registry

    def ask(self, question: str) -> str:
        """Ищет контекст и генерирует ответ через LLM."""
        print(f"Поиск по базе для вопроса: '{question}'...")
        context_chunks = self.indexer.search(question, top_k=4)

        if not context_chunks:
            return "В базе данных не найдено информации по этому вопросу."

        # Формируем контекст для LLM
        context_text = ""
        for i, chunk in enumerate(context_chunks, 1):
            source = Path(chunk['source']).name if hasattr(chunk, 'source') else chunk['source']
            context_text += f"--- Фрагмент {i} (Источник: {source}) ---\n"
            context_text += chunk['text'] + "\n\n"

        system_prompt = (
            "Ты — ассистент по работе с документами. Отвечай на вопрос пользователя, "
            "ОПИРАЯСЬ ТОЛЬКО на предоставленные фрагменты текста. "
            "Если в тексте нет ответа, честно скажи, что не знаешь. "
            "Обязательно указывай, из какого файла взята информация."
        )

        user_prompt = f"КОНТЕКСТ:\n{context_text}\n\nВОПРОС: {question}"

        print("Генерация ответа (local_logic)...")
        llm = self.registry.get_model_for_task("complex_reasoning") # DeepSeek R1 8B
        return llm.generate(prompt=user_prompt, system_prompt=system_prompt)
