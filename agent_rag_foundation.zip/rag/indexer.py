import os
from pathlib import Path
import chromadb
from sentence_transformers import SentenceTransformer
from documents.extractors import extract_text

class RAGIndexer:
    def __init__(self, config: dict, tools_config: dict):
        self.rag_config = config.get("rag", {})
        self.tools_config = tools_config

        self.db_path = self.rag_config.get("db_path", "chroma_db")
        self.collection_name = self.rag_config.get("collection_name", "documents")
        self.chunk_size = self.rag_config.get("chunk_size", 1000)
        self.chunk_overlap = self.rag_config.get("chunk_overlap", 200)

        print(f"Загрузка модели эмбеддингов ({self.rag_config.get('embedding_model')})...")
        self.embedder = SentenceTransformer(self.rag_config.get("embedding_model"))

        self.client = chromadb.PersistentClient(path=self.db_path)
        # Используем встроенную функцию эмбеддингов от sentence-transformers
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            embedding_function=chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction(
                model_name=self.rag_config.get("embedding_model")
            )
        )

    def _chunk_text(self, text: str) -> list[str]:
        """Разбивает текст на пересекающиеся кусочки."""
        chunks = []
        start = 0
        while start < len(text):
            end = start + self.chunk_size
            chunks.append(text[start:end])
            start += self.chunk_size - self.chunk_overlap
        return chunks

    def index_folder(self, folder_path: str):
        """Индексирует все поддерживаемые файлы в папке."""
        folder = Path(folder_path)
        supported_exts = ['.txt', '.docx', '.doc', '.xlsx', '.xls', '.pdf', '.png', '.jpg', '.jpeg']

        files_to_index = [f for f in folder.rglob('*') if f.suffix.lower() in supported_exts]
        print(f"Найдено файлов для индексации: {len(files_to_index)}")

        doc_id_counter = 0
        for file_path in files_to_index:
            print(f"Обработка: {file_path.name}...")
            text = extract_text(str(file_path), self.tools_config)

            if text.startswith("[Ошибка]"):
                print(f"  Пропуск (ошибка чтения): {text}")
                continue

            chunks = self._chunk_text(text)
            if not chunks:
                continue

            ids = [f"{file_path.name}_chunk_{i}" for i in range(len(chunks))]
            metadatas = [{"source": str(file_path)} for _ in chunks]

            # Добавляем в базу пакетами, чтобы не вешать память
            self.collection.add(
                documents=chunks,
                metadatas=metadatas,
                ids=ids
            )
            doc_id_counter += 1

        print(f"✅ Индексация завершена! Обработано документов: {doc_id_counter}")
        return doc_id_counter

    def search(self, query: str, top_k: int = 4) -> list[dict]:
        """Ищет самые релевантные кусочки текста по запросу."""
        results = self.collection.query(
            query_texts=[query],
            n_results=top_k
        )

        found_chunks = []
        if results['documents']:
            for i in range(len(results['documents'][0])):
                found_chunks.append({
                    "text": results['documents'][0][i],
                    "source": results['metadatas'][0][i]['source']
                })
        return found_chunks
