import os
import time
import yaml
from llm.registry import LLMRegistry
from documents.extractors import extract_text
from documents.writers import create_simple_docx
from core.prompts import SUMMARIZE_PROMPT, STRUCTURE_PROMPT, SPELLCHECK_PROMPT, CODE_PROMPT
from core.workspace import WorkspaceManager
from tools.validator import validate_python_code

class Agent:
    def __init__(self, config_path="config.yaml"):
        with open(config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        self.tools = self.config.get("tools", {})
        self.registry = LLMRegistry(config_path)

        safety = self.config.get("safety", {})
        self.workspace = WorkspaceManager(
            workspace_dir=safety.get("workspace_dir", "workspace"),
            read_only_originals=safety.get("read_only_originals", True)
        )

        # Настройки цикла
        agent_loop = self.config.get("agent_loop", {})
        self.max_iterations = agent_loop.get("max_iterations", 10)
        self.task_timeout = agent_loop.get("task_timeout_seconds", 600)
        self.code_timeout = agent_loop.get("code_execution_timeout", 15)

        # Флаг экстренной остановки
        self._stop_requested = False

    def request_stop(self):
        """Вызывается из интерфейса (кнопка 'Стоп'), чтобы прервать работу."""
        print("\n[СИГНАЛ] Получен запрос на экстренную остановку агента!")
        self._stop_requested = True

    def reset_stop_flag(self):
        """Сбрасывает флаг перед новой задачей."""
        self._stop_requested = False

    def _read_safe(self, file_path: str) -> str:
        safe_path = self.workspace.prepare_file(file_path)
        return extract_text(safe_path, self.tools)

    def generate_code_with_validation(self, task: str) -> str:
        self.reset_stop_flag() # Сбрасываем кнопку стоп перед стартом
        print(f"Генерация кода (лимит: {self.max_iterations} попыток, таймаут: {self.task_timeout} сек)...")

        llm = self.registry.get_model_for_task("code_generation")
        current_prompt = CODE_PROMPT.format(task=task)

        last_generated_code = ""
        start_time = time.time()

        for iteration in range(1, self.max_iterations + 1):
            # 1. Проверка экстренной остановки
            if self._stop_requested:
                print("\n[ОСТАНОВКА] Агент прерван пользователем. Возвращаю последний результат.")
                return f"--- РАБОТА ПРЕРВАНА ПОЛЬЗОВАТЕЛЕМ ---\n\n{last_generated_code}"

            # 2. Проверка таймаута
            elapsed_time = time.time() - start_time
            if elapsed_time > self.task_timeout:
                print(f"\n[ТАЙМАУТ] Истекло время ({self.task_timeout} сек). Прерываю работу.")
                return f"--- ПРЕВЫШЕН ЛИМИТ ВРЕМЕНИ ({self.task_timeout} сек) ---\n\n{last_generated_code}"

            print(f"--- Попытка {iteration} (прошло {int(elapsed_time)} сек) ---")

            # Генерируем код
            code = llm.generate(current_prompt)
            last_generated_code = code # Сохраняем на случай экстренного выхода

            print("Валидация кода...")
            is_valid, error_msg = validate_python_code(code, timeout_sec=self.code_timeout)

            if is_valid:
                print("✅ Код прошел валидацию!")
                return code

            print(f"❌ Ошибка в коде: {error_msg}")
            current_prompt = (
                f"Твой предыдущий код выдал ошибку:\n{error_msg}\n\n"
                f"Вот код, который ты написал:\n{code}\n\n"
                f"Пожалуйста, исправь его и верни только чистый рабочий код. Задача: {task}"
            )

        print("⚠️ Достигнут лимит попыток.")
        return f"--- ДОСТИГНУТ ЛИМИТ ПОПЫТОК ({self.max_iterations}) ---\n\n{last_generated_code}"

    # Остальные методы (summarize, check_spelling, structure) оставляем без изменений
    def summarize_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("default_model")
        return llm.generate(SUMMARIZE_PROMPT.format(text=text[:8000]))

    def check_spelling_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("default_model")
        return llm.generate(SPELLCHECK_PROMPT.format(text=text[:8000]))

    def structure_file(self, file_path: str) -> str:
        text = self._read_safe(file_path)
        if text.startswith("[Ошибка]"): return text
        llm = self.registry.get_model_for_task("complex_reasoning")
        return llm.generate(STRUCTURE_PROMPT.format(text=text[:8000]))

    def save_text_to_word(self, text: str, output_path: str):
        create_simple_docx(text, output_path)
        return output_path
